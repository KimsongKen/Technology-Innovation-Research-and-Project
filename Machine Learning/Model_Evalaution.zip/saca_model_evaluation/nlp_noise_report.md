# NLP Noise Robustness Report

- Samples evaluated: `2920`
- SBERT model: `all-MiniLM-L6-v2`
- Winner (least performance drop): `CatBoost`

## Drop Summary (Lower is Better)

| Model | Disease F1w Drop | Severity F1w Drop | Severe Recall Drop | Combined Drop Score |
| --- | --- | --- | --- | --- |
| ExtraNGvboost | 0.0796 | 0.0516 | 0.0214 | 0.0568 |
| CatBoost | 0.0426 | 0.0340 | 0.0236 | 0.0354 |

## Mapping Quality

- Average clean symptom count per sample: `5.9363`
- Average mapped symptom count after noise+SBERT: `5.6849`
