import importlib
import sys
import unittest
from unittest.mock import patch

import numpy as np


class _FakeModel:
    def __init__(self, probs):
        self._probs = np.array([probs], dtype=float)

    def predict_proba(self, _x):
        return self._probs


class _FakeEncoder:
    def __init__(self, classes):
        self.classes_ = np.array(classes)


class PredictorTestCase(unittest.TestCase):
    def _load_predictor_module(self):
        if "predictor" in sys.modules:
            del sys.modules["predictor"]

        fake_objects = [
            _FakeModel([0.1, 0.2, 0.7]),  # severity model
            _FakeModel([0.6, 0.4]),       # disease model
            _FakeEncoder(["Mild", "Moderate", "Severe"]),
            _FakeEncoder(["Flu", "Pulmonary Embolism"]),
            ["sharp chest pain", "fever", "shortness of breath"],
        ]

        with patch("joblib.load", side_effect=fake_objects):
            predictor = importlib.import_module("predictor")

        return predictor

    def test_predict_result_structure_and_values(self):
        predictor = self._load_predictor_module()

        result = predictor.predict(["Chest Pain", "fever", "unknown symptom"])

        self.assertEqual(result["severity"], "Severe")
        self.assertEqual(result["disease"], "Flu")
        self.assertEqual(result["severity_confidence"], 0.7)
        self.assertEqual(result["disease_confidence"], 0.6)
        self.assertEqual(result["matched_syms"], ["sharp chest pain", "fever"])
        self.assertEqual(result["unmatched_syms"], ["unknown symptom"])
        self.assertEqual(
            result["severity_probs"],
            {"Mild": 0.1, "Moderate": 0.2, "Severe": 0.7},
        )
        self.assertIn("Moderate confidence", result["suggestion"])
        self.assertIn("Only 2 symptom(s) matched", result["symptom_hint"])


if __name__ == "__main__":
    unittest.main()
