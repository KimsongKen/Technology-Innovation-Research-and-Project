# SACA Text Modality — Interface Documentation (v2)
**For**     : NLP Module Developer  
**From**    : ML Module Developer  
**Project** : Swin Smart Adaptive Clinical Assistant (SACA)  
**Updated** : April 2026

---

## 1. Overview

The ML Text Modality module accepts a **list of English symptom strings** and returns:
- **Severity prediction** — Mild / Moderate / Severe
- **Disease prediction** — one of 40 common disease names

Your NLP module is responsible for:
1. Extracting symptom keywords from free-text English input
2. Translating Warlpiri symptom words into English
3. Passing the English symptom list to `predict()`

---

## 2. Setup

### Required Files
Place all these files in the **same folder**:
```
predictor.py
saca_severity_model.pkl
saca_disease_model.pkl
label_encoder_severity.pkl
label_encoder_disease.pkl
symptom_columns.pkl
```

### Install Dependencies
```bash
pip install scikit-learn numpy joblib
```

### Import
```python
from predictor import predict
```

---

## 3. Function Reference

### `predict(symptom_list)`

**Input**

| Parameter | Type | Description |
|-----------|------|-------------|
| `symptom_list` | `list[str]` | List of symptom strings in English |

**Rules**
- Strings must be **lowercase**
- Each item is **one symptom** (not a full sentence)
- Minimum **1 symptom**, recommended **5-6** for high confidence
- Order does not matter

```python
# Correct
predict(['chest pain', 'fever', 'shortness of breath'])

# Wrong — full sentence, not symptom keywords
predict(['I have chest pain and fever'])
```

---

**Output**

```python
{
    'severity'           : str,    # 'Mild', 'Moderate', or 'Severe'
    'severity_confidence': float,  # 0.0 ~ 1.0
    'disease'            : str,    # disease name (one of 40 diseases)
    'disease_confidence' : float,  # 0.0 ~ 1.0
    'severity_probs'     : dict,   # probability for each severity class
    'matched_syms'       : list,   # symptoms successfully matched
    'unmatched_syms'     : list,   # symptoms not recognised
    'suggestion'         : str,    # confidence-based advice
    'symptom_hint'       : str,    # symptom count guidance
}
```

**Example Output**
```python
{
    'severity'           : 'Severe',
    'severity_confidence': 0.818,
    'disease'            : 'pulmonary embolism',
    'disease_confidence' : 0.519,
    'severity_probs'     : {
        'Mild'    : 0.091,
        'Moderate': 0.091,
        'Severe'  : 0.818
    },
    'matched_syms'       : ['sharp chest pain', 'shortness of breath', 'fever', 'sweating'],
    'unmatched_syms'     : [],
    'suggestion'         : 'High confidence — result is reliable',
    'symptom_hint'       : '4 symptoms matched — sufficient for reliable prediction'
}
```

---

## 4. Confidence Guide

| Severity Confidence | Label | Meaning |
|---------------------|-------|---------|
| ≥ 0.80 | High | Result is reliable |
| 0.60 – 0.79 | Moderate | Consider adding more symptoms |
| < 0.60 | Low | Add more symptoms (recommend 5-6) |

### Confidence vs Number of Symptoms

| Symptoms | Typical Confidence |
|----------|--------------------|
| 1 | ~46% |
| 3 | ~64% |
| 4 | ~84% |
| 6 | ~91% |

---

## 5. Synonym Mapping (Already Handled)

The following common terms are **already mapped** inside `predictor.py`.
You do NOT need to handle these — just pass them as-is.

| User Input | Mapped To |
|------------|-----------|
| chest pain | sharp chest pain |
| blurred vision | diminished vision |
| can't breathe | shortness of breath |
| difficulty breathing | shortness of breath |
| stomach pain | sharp abdominal pain |
| stomachache | sharp abdominal pain |
| tummy ache | sharp abdominal pain |
| feel sick | nausea |
| throwing up | vomiting |
| heart racing | increased heart rate |
| fast heartbeat | increased heart rate |
| runny nose | nasal congestion |
| blocked nose | nasal congestion |
| tired | fatigue |
| exhausted | fatigue |
| dizzy | dizziness |
| weak | weakness |
| shivering | chills |
| no appetite | decreased appetite |
| weight loss | recent weight loss |
| swollen | skin swelling |
| confused | altered sensorium |
| numb | loss of sensation |
| seizure | seizures |
| depressed | depression |
| nervous | anxiety and nervousness |

---

## 6. Supported Diseases (40 classes)

```
acute bronchitis          acute kidney injury        acute pancreatitis
anxiety                   appendicitis               arthritis of the hip
bursitis                  complex regional pain syndrome
conjunctivitis due to allergy                        cystitis
dental caries             diabetic ketoacidosis       diverticulitis
eczema                    esophagitis                fungal infection of the hair
gastrointestinal hemorrhage                          gout
heart attack              heart failure              hypoglycemia
infectious gastroenteritis                           injury to the arm
injury to the leg         marijuana abuse            multiple sclerosis
noninfectious gastroenteritis                        nose disorder
obstructive sleep apnea (osa)                        peripheral nerve disorder
pneumonia                 pulmonary embolism         sepsis
sickle cell crisis        spontaneous abortion       sprain or strain
strep throat              stroke                     transient ischemic attack
vulvodynia
```

---

## 7. Warlpiri Translation (Your Responsibility)

After translating Warlpiri terms to English symptoms, pass them directly to `predict()`.

```python
WARLPIRI_TO_ENGLISH = {
    'ngurlu-ngurlu' : 'chest pain',
    'kari'          : 'nausea',
    'yarda'         : 'fever',
    'wirlinyi'      : 'headache',
    'karrinji'      : 'back pain',
    # Add more terms here
}

def translate_warlpiri(warlpiri_symptoms: list) -> list:
    return [WARLPIRI_TO_ENGLISH.get(s.lower(), s) for s in warlpiri_symptoms]

# Usage
warlpiri_input   = ['ngurlu-ngurlu', 'yarda']
english_symptoms = translate_warlpiri(warlpiri_input)
result           = predict(english_symptoms)
```

---

## 8. Full Integration Example

```python
from predictor import predict

# English input
result = predict(['chest pain', 'fever', "can't breathe", 'sweating'])
print(f"Severity : {result['severity']} ({result['severity_confidence']})")
print(f"Disease  : {result['disease']} ({result['disease_confidence']})")
print(f"Matched  : {result['matched_syms']}")
print(f"Hint     : {result['symptom_hint']}")

# Warlpiri input (after translation)
english = translate_warlpiri(['ngurlu-ngurlu', 'yarda'])
result  = predict(english)
print(f"Severity : {result['severity']}")
```

---

## 9. JSON Format (for testing)

```python
import json
from predictor import predict

input_data = {"symptoms": ["chest pain", "fever", "shortness of breath"]}
result     = predict(input_data["symptoms"])

print(json.dumps({
    "input"              : input_data,
    "severity"           : result["severity"],
    "severity_confidence": result["severity_confidence"],
    "disease"            : result["disease"],
    "disease_confidence" : result["disease_confidence"],
    "severity_probs"     : result["severity_probs"],
    "matched_symptoms"   : result["matched_syms"],
    "unmatched_symptoms" : result["unmatched_syms"],
    "suggestion"         : result["suggestion"],
    "symptom_hint"       : result["symptom_hint"],
}, indent=4, ensure_ascii=False))
```

---

## 10. Unmatched Symptoms

If `unmatched_syms` is not empty, the symptom was not recognised.

**Fix options:**
1. Check if it is in the Synonym Map above — if yes, it is already handled
2. If it is a Warlpiri word — add it to `WARLPIRI_TO_ENGLISH`
3. If it is a valid English symptom — contact ML developer to add to `SYNONYM_MAP`

To see all 377 supported symptom column names:
```python
import joblib
sym_cols = joblib.load('symptom_columns.pkl')
print(sym_cols)
```

---

## 11. Model Performance

| Task | Model | Accuracy | Notes |
|------|-------|----------|-------|
| Severity | ET + HGBM (weight=2) | **97.61%** | Severe Recall: 97.71% |
| Disease | HGBM | **94.76%** | 40 disease classes |

**Cost-Sensitive Learning**: Severe cases are weighted 2x to minimise risk of undertriage in life-threatening situations.
