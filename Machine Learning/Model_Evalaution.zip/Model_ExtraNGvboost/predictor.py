"""
SACA — Text Modality Predictor
For NLP team: import this module and call predict()

Usage:
    from predictor import predict

    result = predict(['chest pain', 'fever', 'shortness of breath'])
    print(result['severity'])   # Severe
    print(result['disease'])    # pulmonary embolism
"""

import numpy as np
import joblib
import os

# ── Load model files ───────────────────────────────────────────
# All .pkl files must be in the same folder as this script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

severity_model = joblib.load(os.path.join(BASE_DIR, 'saca_severity_model.pkl'))
disease_model  = joblib.load(os.path.join(BASE_DIR, 'saca_disease_model.pkl'))
le_sev         = joblib.load(os.path.join(BASE_DIR, 'label_encoder_severity.pkl'))
le_dis         = joblib.load(os.path.join(BASE_DIR, 'label_encoder_disease.pkl'))
sym_cols       = joblib.load(os.path.join(BASE_DIR, 'symptom_columns.pkl'))

# ── Synonym mapping ────────────────────────────────────────────
# Maps common user input terms to dataset column names
SYNONYM_MAP = {
    # Chest
    'chest pain'            : 'sharp chest pain',
    'chest hurt'            : 'sharp chest pain',
    'chest hurts'           : 'sharp chest pain',
    'heart pain'            : 'sharp chest pain',
    'chest discomfort'      : 'chest tightness',
    # Vision
    'blurred vision'        : 'diminished vision',
    'blurry vision'         : 'diminished vision',
    "can't see clearly"     : 'diminished vision',
    'vision problems'       : 'diminished vision',
    'seeing double'         : 'double vision',
    # Breathing
    'breathless'            : 'shortness of breath',
    "can't breathe"         : 'shortness of breath',
    'cant breathe'          : 'shortness of breath',
    'difficulty breathing'  : 'shortness of breath',
    'hard to breathe'       : 'shortness of breath',
    # Stomach
    'stomach pain'          : 'sharp abdominal pain',
    'stomach ache'          : 'sharp abdominal pain',
    'stomachache'           : 'sharp abdominal pain',
    'tummy ache'            : 'sharp abdominal pain',
    'belly pain'            : 'sharp abdominal pain',
    'abdominal pain'        : 'sharp abdominal pain',
    # Nausea / Vomiting
    'feel sick'             : 'nausea',
    'feeling sick'          : 'nausea',
    'throwing up'           : 'vomiting',
    'threw up'              : 'vomiting',
    'puking'                : 'vomiting',
    # Heart
    'heart racing'          : 'increased heart rate',
    'racing heart'          : 'increased heart rate',
    'fast heartbeat'        : 'increased heart rate',
    'heart pounding'        : 'palpitations',
    'slow heartbeat'        : 'decreased heart rate',
    # Head
    'head pain'             : 'headache',
    'migraine'              : 'headache',
    'head hurts'            : 'headache',
    # Throat / Nose
    'runny nose'            : 'nasal congestion',
    'blocked nose'          : 'nasal congestion',
    'stuffy nose'           : 'nasal congestion',
    'throat pain'           : 'sore throat',
    'throat hurts'          : 'sore throat',
    # Skin
    'rash'                  : 'skin rash',
    'itchy skin'            : 'itching of skin',
    # General
    'tired'                 : 'fatigue',
    'exhausted'             : 'fatigue',
    'weak'                  : 'weakness',
    'dizzy'                 : 'dizziness',
    'lightheaded'           : 'dizziness',
    'sweat'                 : 'sweating',
    'shivering'             : 'chills',
    'no appetite'           : 'decreased appetite',
    'loss of appetite'      : 'decreased appetite',
    'weight loss'           : 'recent weight loss',
    'swollen'               : 'skin swelling',
    'swelling'              : 'skin swelling',
    'muscle ache'           : 'muscle pain',
    'body ache'             : 'ache all over',
    'loose stool'           : 'diarrhea',
    'burning urination'     : 'painful urination',
    'cant sleep'            : 'insomnia',
    "can't sleep"           : 'insomnia',
    'nervous'               : 'anxiety and nervousness',
    'anxiety'               : 'anxiety and nervousness',
    'depressed'             : 'depression',
    'seizure'               : 'seizures',
    'fit'                   : 'seizures',
    'confused'              : 'altered sensorium',
    'confusion'             : 'altered sensorium',
    'numb'                  : 'loss of sensation',
    'numbness'              : 'loss of sensation',
}


def predict(symptom_list: list) -> dict:
    """
    Predict severity and disease from a list of symptom strings.

    Args:
        symptom_list (list): List of symptom strings in English.
                             e.g. ['chest pain', 'fever', 'shortness of breath']

    Returns:
        dict: {
            'severity'           : 'Mild' / 'Moderate' / 'Severe',
            'severity_confidence': float (0.0 - 1.0),
            'disease'            : str (disease name),
            'disease_confidence' : float (0.0 - 1.0),
            'matched_syms'       : list of matched symptom names,
            'unmatched_syms'     : list of unrecognised symptom names,
            'severity_probs'     : dict of probabilities per class,
            'suggestion'         : str (confidence-based advice),
            'symptom_hint'       : str (symptom count guidance),
        }
    """
    # Build one-hot input vector
    x       = np.zeros((1, len(sym_cols)), dtype=np.float32)
    matched = []
    unmatch = []

    for sym in symptom_list:
        sym_clean  = sym.strip().lower()
        # Apply synonym mapping
        sym_mapped = SYNONYM_MAP.get(sym_clean, sym_clean)
        if sym_mapped in sym_cols:
            x[0, sym_cols.index(sym_mapped)] = 1.0
            matched.append(sym_mapped)
        else:
            unmatch.append(sym_clean)

    # Severity prediction
    sev_proba = severity_model.predict_proba(x)[0]
    sev_label = le_sev.classes_[np.argmax(sev_proba)]
    sev_conf  = float(np.max(sev_proba))

    # Disease prediction
    dis_proba = disease_model.predict_proba(x)[0]
    dis_label = le_dis.classes_[np.argmax(dis_proba)]
    dis_conf  = float(np.max(dis_proba))

    # Confidence-based suggestion
    if sev_conf >= 0.80:
        suggestion = 'High confidence — result is reliable'
    elif sev_conf >= 0.60:
        suggestion = 'Moderate confidence — consider adding more symptoms'
    else:
        suggestion = 'Low confidence — please add more symptoms (recommended: 5-6)'

    # Symptom count hint
    n = len(matched)
    if n < 3:
        symptom_hint = f'Only {n} symptom(s) matched — more symptoms will improve accuracy'
    elif n < 4:
        symptom_hint = f'{n} symptoms matched — adding 1-2 more may increase confidence'
    else:
        symptom_hint = f'{n} symptoms matched — sufficient for reliable prediction'

    return {
        'severity'           : sev_label,
        'severity_confidence': round(sev_conf, 3),
        'disease'            : dis_label,
        'disease_confidence' : round(dis_conf, 3),
        'matched_syms'       : matched,
        'unmatched_syms'     : unmatch,
        'severity_probs'     : {
            cls: round(float(p), 3)
            for cls, p in zip(le_sev.classes_, sev_proba)
        },
        'suggestion'         : suggestion,
        'symptom_hint'       : symptom_hint,
    }


# ── Quick test ─────────────────────────────────────────────────
if __name__ == '__main__':
    import json

    test_cases = [
        ['sharp chest pain', 'shortness of breath', 'fever', 'sweating'],
        ['sore throat', 'cough', 'nasal congestion'],
        ['fatigue', 'increased urination', 'weight loss'],
    ]

    for symptoms in test_cases:
        result = predict(symptoms)
        print(json.dumps({
            'input'   : symptoms,
            'severity': result['severity'],
            'disease' : result['disease'],
            'confidence': result['severity_confidence'],
        }, ensure_ascii=False, indent=2))
        print()
